package Main;

public interface Commons {

    int WIDTH = 1024;
    int HEIGHT = 720;
    int BOTTOM_EDGE = 1024;
    int N_OF_BRICKS = 30;
    int INIT_PADDLE_X = WIDTH/2;
    int INIT_PADDLE_Y = HEIGHT-44;
    int PERIOD = 10;
}
