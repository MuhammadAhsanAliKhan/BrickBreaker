package Objects;

public class PowerUpIncSize extends PowerUp {
    PowerUpIncSize(){
        super();
        PowerUpName = "long";
        path ="src/PNG/47-Breakout-Tiles.png";
        loadImage();
        getImageDimensions();
    }
}