package Objects;

public interface PausableInterface {
    public void pause();
    public void unpause();
}
