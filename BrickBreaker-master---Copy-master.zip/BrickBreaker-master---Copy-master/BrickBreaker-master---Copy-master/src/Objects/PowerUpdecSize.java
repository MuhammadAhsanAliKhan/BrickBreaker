package Objects;

public class PowerUpdecSize extends PowerUp {
    PowerUpdecSize(){
        super();
        PowerUpName = "small";
        path ="src/PNG/46-Breakout-Tiles.png";
        loadImage();
        getImageDimensions();
    }
}