package Objects;

public class PowerUpdecSpeed extends PowerUp {
    PowerUpdecSpeed(){
        super();
        PowerUpName = "slow";
        path ="src/PNG/41-Breakout-Tiles.png";
        loadImage();
        getImageDimensions();
    }
}